package AutomationProject;

import org.testng.annotations.Test;
import POMPackage.POM_SwagLabs;
import org.testng.annotations.BeforeTest;

import java.sql.Driver;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

@Test
public class ParallelTesting_SwagLab 
{
	private static final WebDriver ChromeDriver = null;


	@BeforeTest
	  public void beforeTest() 
	  {
		System.setProperty("webdriver.chrome.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	  }
	
  public void swagLab(String username, String password) throws InterruptedException 
  {
	  POMPackage.POM_SwagLabs p= new POMPackage.POM_SwagLabs();
	 
	    //p.implicitWait(driver);
		p.url(ChromeDriver);
		p.username(ChromeDriver, username);
		p.password(ChromeDriver, password);
		Thread.sleep(2000);
		p.loginButton(ChromeDriver);
		p.admin(ChromeDriver);
		Thread.sleep(2000);
		p.logout(ChromeDriver);
  }
  
  //@DataProvider//Test Management which is 2D array stores username and password.
  public Object[][] dp() 
  {
    return new Object[][] 
    {
      new Object[] { "standard_user", "secret_sauce" },
      new Object[] { "locked_out_user", "secret_sauce" },
      new Object[] { "problem_user", "secret_sauce" },
      new Object[] { "performance_glitch_user", "secret_sauce" },
      new Object[] { "error_user", "secret_sauce" },
      new Object[] { "visual_user", "secret_sauce" }
    };
  }

  @AfterTest
  public void afterTest() 
  {
	  ChromeDriver.close();
  }

}
