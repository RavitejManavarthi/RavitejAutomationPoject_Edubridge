package AutomationProject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.sql.Driver;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class URL_Validation 
{
	@BeforeTest
	  public void beforeTest() 
	  {
		System.setProperty("webdriver.chrome.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
	  }
  @Test
  public void f() 
  {
	  String expectedURL="https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		System.out.println("Expected URL: "+expectedURL);
		ChromeDriver chromeDriver = new ChromeDriver();
		//URL
		chromeDriver.get(expectedURL);
		
		String actualURL = new String();
		System.out.println("Actual URL: "+actualURL);
		
		//URL Validation
		if(expectedURL.equals(actualURL))
		{
			System.out.println("URL Validation is Passed.");
		}
		else
		{
			System.out.println("URL Validation is Failed.");
		}
  }
  

  @AfterTest
  public void afterTest() 
  {
	  
  }

}
