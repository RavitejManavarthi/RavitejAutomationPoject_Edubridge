package HybridFramework;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OperationalClass 
{
	public void maximizeBrowser(WebDriver driver)
	{
		driver.manage().window().maximize();
	}
	public void deleteAllCookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
	public void implicitWait(WebDriver driver)
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	public void url(WebDriver driver)
	{
		driver.get("https://www.saucedemo.com/");
	}
	public void username(WebDriver driver,String usn)
	{
		driver.findElement(By.id("user-name")).sendKeys(usn);
	}
	public void password(WebDriver driver, String pwd)
	{
		driver.findElement(By.id("password")).sendKeys(pwd);
	}
	public void loginButton(WebDriver driver)
	{
		driver.findElement(By.id("login-button")).click();
	}
	public void admin(WebDriver driver) 
	{
		 driver.findElement(By.id("react-burger-menu-btn")).click();
	}
	public void logout(WebDriver driver)
	{
		driver.findElement(By.id("logout_sidebar_link")).click();
	}
	public void closeBrowser(WebDriver driver) 
	{
		driver.close();
	}
}
