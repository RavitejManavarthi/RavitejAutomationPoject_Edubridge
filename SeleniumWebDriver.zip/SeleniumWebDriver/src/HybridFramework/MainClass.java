package HybridFramework;

import java.time.Duration;
import org.openga.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainClass 
{
	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5000));
		ReadExcelClass r= new ReadExcelClass();
		r.readExcel(driver);
	}
}
