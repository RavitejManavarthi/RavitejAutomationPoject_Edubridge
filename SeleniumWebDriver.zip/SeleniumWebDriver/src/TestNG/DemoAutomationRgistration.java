package TestNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class DemoAutomationRgistration {
	
	@BeforeTest
	  public void beforeTest() 
	{
		System.setProperty("webdriver.chrome.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
	  }
	
  @Test
  public void f() 
  {
	  
  }
  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }

  
  @AfterTest
  public void afterTest() {
  }

}
