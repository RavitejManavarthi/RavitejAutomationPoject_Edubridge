package TestNG;

import org.testng.annotations.Test;

import POMPackage.POM_SwagLabs;

import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;
import org.openga.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class MultipleTestCase_Dataprovider_DDT 
{
	org.openqa.selenium.WebDriver driver;
	@BeforeTest
	  public void beforeTest() 
	  {
		System.setProperty("webdriver.chrome.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
	  }
  @Test(dataProvider = "dp")
  public void f(Integer username, String password) 
  {
	  POM_SwagLabs p= new POM_SwagLabs();
	  p.url(driver);
	  p.username(driver, "standard_user");
	  p.password(driver, "secret_sauce"); 
	  p.loginButton(driver);
	  p.admin(driver);
	  p.logout(driver);
  }

  @DataProvider
  public Object[][] dp() 
  {
    return new Object[][] {
      new Object[] { 1, "a" },
      new Object[] { 2, "b" },
    };
  }
  

  @AfterTest
  public void afterTest() {
  }

}
