package TestNG;

import org.openga.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;

public class BaseClass 
{
	@FindBy(id="user-name")
	WebElement username;
	
	@FindBy(id="password")
	WebElement password;
	
	@FindBy(id="login-button")
	WebElement loginButton;
	
	@FindBy(id="react-burger-menu-btn")
	WebElement admin;
	
	@FindBy(id="logout-sidebar-link")
	WebElement logout;
	
  
  public void loginLogout(WebDriver driver, String usn, String pwd) 
  {
	  
  }
}
