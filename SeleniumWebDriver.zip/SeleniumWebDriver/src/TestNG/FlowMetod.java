package TestNG;

public class FlowMetod 
{

}
