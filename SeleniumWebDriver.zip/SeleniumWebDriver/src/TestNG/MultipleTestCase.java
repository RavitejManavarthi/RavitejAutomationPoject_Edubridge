package TestNG;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import POMPackage.POM_SwagLabs;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class MultipleTestCase 
{
	org.openqa.selenium.WebDriver driver;
  
	@BeforeTest
	  public void beforeTest() 
	  {
		System.setProperty("webdriver.chrome.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
	  }
	
  @Test(priority=1,description = "checking login functionality")
  public void swaglabLogin() 
  {
	  POM_SwagLabs p= new POM_SwagLabs();
	  p.url(driver);
	  p.username(driver, "standard_user");
	  p.password(driver, "secret_sauce"); 
	  p.loginButton(driver);
	  p.admin(driver);
	  p.logout(driver);
	  
  }
  

  @AfterTest
  public void afterTest() 
  {
	  
  }

}
