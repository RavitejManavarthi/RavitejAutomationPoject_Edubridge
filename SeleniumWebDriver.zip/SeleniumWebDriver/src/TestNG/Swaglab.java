package TestNG;

import org.testng.annotations.Test;

public class Swaglab {
  @Test
  public void f() {
  }
}
