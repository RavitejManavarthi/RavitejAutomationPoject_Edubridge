package Project;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Project2 {

	public static void main(String[] args) throws InterruptedException 
	{
	
		System.setProperty("webdriver.chrome.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://demo.automationtesting.in/Register.html");
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[1]/div[1]/input")).sendKeys("RaviTej");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[1]/div[2]/input")).sendKeys("M");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[2]/div/textarea")).sendKeys("Hyderabad");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[3]/div[1]/input")).sendKeys("mvravitej@gmail.com");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[4]/div/input")).sendKeys("9533428716");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[5]/div/label[1]/input")).click();
		Thread.sleep(2000);
		
		//.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[9]/div/select")).click();
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[10]/div/span/span[1]/span/span[1]")).click();
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[12]/div/input")).sendKeys("Kalyani");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[13]/div/input")).sendKeys("Kalyani");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[14]/div/button[1]")).click();
		
		//driver.close();
	}

}
