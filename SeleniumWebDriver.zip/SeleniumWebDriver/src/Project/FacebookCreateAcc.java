package Project;


import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FacebookCreateAcc 
{

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.facebook.com/reg/");
			
		driver.findElement(By.name("firstname")).sendKeys("Ravi");
		Thread.sleep(2000);
		
		driver.findElement(By.name("lastname")).sendKeys("M");
		Thread.sleep(2000);
		

		driver.findElement(By.name("reg_email__")).sendKeys("mvravitej@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.name("reg_email_confirmation__")).sendKeys("mvravitej@gmail.com");
		Thread.sleep(2000);
		
		driver.findElement(By.name("reg_passwd__")).sendKeys("RaviMV");
		Thread.sleep(2000);
		
		Select selDate = new Select(driver.findElement(By.name("birthday_day")));
		Select selMonth = new Select(driver.findElement(By.id("month")));
		Select selYear = new Select(driver.findElement(By.id("year")));
		
		selDate.selectByVisibleText("21");
		Thread.sleep(2000);
		selMonth.selectByVisibleText("Jun");
		Thread.sleep(2000);
		selYear.selectByVisibleText("1989");
		
		driver.findElement(By.xpath("//input[@type='radio' and @value='2']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//button[text()='Sign Up']")).click();
		
	
		driver.quit();
		
	}

}
