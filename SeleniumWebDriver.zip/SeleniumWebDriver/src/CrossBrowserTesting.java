import java.util.Scanner;

import org.openga.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class CrossBrowserTesting 
{

	public static void main(String[] args) 
	{
	Scanner s= new Scanner(System.in);
	System.out.println("Enter 1 for GoogleChrome. \nEnter 2 for Edge.");
	int choice=s.nextInt();
	
	WebDriver driver = null;
	switch(choice)
	{
	case 1:
		System.setProperty("webdriver.chrome.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\chromedriver.exe");
		driver= new ChromeDriver();
		
		
	case 2:
		System.setProperty("webdriver.opera.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\Opera driver\\operadriver.exe");
		driver= new 
		
		
	}

	}

}
