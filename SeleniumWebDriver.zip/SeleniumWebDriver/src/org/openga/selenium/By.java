package org.openga.selenium;

public class By {

}
