package org.openga.selenium;

public enum WebDriver {
	;

	Object manage() {
		// TODO Auto-generated method stub
		return null;
	}

}
