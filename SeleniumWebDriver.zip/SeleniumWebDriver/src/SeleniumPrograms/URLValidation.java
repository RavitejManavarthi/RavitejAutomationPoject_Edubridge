package SeleniumPrograms;

public class URLValidation {

	public static void main(String[] args) 
	{
		

	}

}
