package POI;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadData 
{
	public static void main(String[] args) throws IOException
	{
		FileInputStream file=new FileInputStream("D:\\Ravitej\\Automation Testing\\POI\\PO.xlsx");
		
		XSSFWorkbook w= new XSSFWorkbook(file);
		
		XSSFSheet s= w.getSheet("ReadData");
		
		
		
	}
}
