package LaunchChromeExtension;

import org.openga.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class LaunchBrowser 
{
	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver","D:\\Ravitej\\Automation Testing\\Browser Extension\\chromedriver.exe");
		ChromeDriver driver= new ChromeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		driver.findElement(By.name("username"));
		driver.close();
	}



}
